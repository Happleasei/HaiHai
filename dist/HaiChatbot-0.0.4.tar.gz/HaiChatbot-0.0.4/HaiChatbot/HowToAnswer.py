# -*- coding: utf-8 -*-
# @Time : 2022/9/9 14:36
# @Author : Wang Hai
# @Email : nicewanghai@163.com
# @Code Specification : PEP8
# @File : HowToAnswer.py
# @Project : HaiHai


class HowToAnswer(object):
    def __init__(self):
        pass

    def listen(self, word):
        pass

    def answer(self, words):
        pass

